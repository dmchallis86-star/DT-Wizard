import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  base: './',
  plugins: [react(), VitePWA({
    registerType: 'autoUpdate',
    includeAssets: ['assets/icon-192.png', 'assets/icon-512.png'],
    manifest: { name: 'D&T Draft HQ', short_name: 'Draft HQ', description: 'A smarter fantasy football draft room', theme_color: '#061018', background_color: '#061018', display: 'standalone', orientation: 'portrait', icons: [{src:'assets/icon-192.png',sizes:'192x192',type:'image/png'},{src:'assets/icon-512.png',sizes:'512x512',type:'image/png'}] }
  })]
});
