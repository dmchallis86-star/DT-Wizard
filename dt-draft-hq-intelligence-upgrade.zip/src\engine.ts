import type{DraftState,Player,Position,Recommendation,Threat}from'./types';
import{maxFall,nextTurns,pickTeam,positionCounts,rosterFor}from'./draft';
import{profileFor}from'./history';

const POS:Position[]=['QB','RB','WR','TE','K','DST'];
const replacement:Record<Position,number>={QB:92,RB:158,WR:176,TE:110,K:230,DST:230};
const clamp=(n:number,a=0,b=1)=>Math.max(a,Math.min(b,n));
const sigmoid=(x:number)=>1/(1+Math.exp(-x));
const seedRand=(seed:number)=>{let s=seed|0;return()=>((s=Math.imul(1664525,s)+1013904223|0)>>>0)/4294967296};
const counts=(roster:Player[])=>positionCounts(roster);
const positionalValue=(p:Player,pool:Player[])=>{const at=pool.filter(x=>x.position===p.position).sort((a,b)=>a.rank-b.rank).findIndex(x=>x.id===p.id);return Math.max(0,(replacement[p.position]-(p.rank+Math.max(0,at)*1.2))*.18)};
const baseSurvival=(p:Player,target:number,current:number)=>clamp(sigmoid((p.adp+maxFall(p)-target)/2.6)*(p.position==='RB'&&p.rank<=36?.74:1)*(target-current>28?.82:1),.01,.98);
const rosterFit=(p:Player,roster:Player[],pick:number,teams:number,rounds:number)=>{const c=counts(roster),r=Math.ceil(pick/teams);let fit=['RB','WR'].includes(p.position)?9:3;if(p.position==='QB'&&c.QB>=1)fit=r>9?0:-25;if(p.position==='TE'&&c.TE>=1)fit=r>9?0:-20;if(['K','DST'].includes(p.position)&&r<rounds-2)fit=-90;if(p.position==='RB'&&c.RB>=6)fit-=13;if(p.position==='WR'&&c.WR>=7)fit-=12;return fit};
const runPressure=(pos:Position,draftIds:string[],players:Player[])=>draftIds.slice(-5).map(id=>players.find(p=>p.id===id)?.position).filter(x=>x===pos).length;
const currentScore=(p:Player,pool:Player[],roster:Player[],state:DraftState,pick:number)=>{const tierLeft=pool.filter(x=>x.position===p.position&&x.tier===p.tier).length;return positionalValue(p,pool)+(52-p.rank*.3)+rosterFit(p,roster,pick,state.settings.teams,state.settings.rounds)+(tierLeft<=2?9:0)+runPressure(p.position,state.picks.map(x=>x.playerId),state.players)*2.2};

function opponentProbability(p:Player,team:number,pick:number,pool:Player[],roster:Player[],state:DraftState){
 const manager=state.managerAssignments[team-1],prof=profileFor(manager),r=Math.ceil(pick/state.settings.teams),w=(r<=5?prof.earlyWeights:prof.lateWeights)[p.position];
 const c=counts(roster),need=p.position==='QB'?c.QB<1:p.position==='TE'?c.TE<1:p.position==='RB'?c.RB<3:p.position==='WR'?c.WR<3:true;
 const blocked=(p.position==='QB'&&c.QB>=2)||(p.position==='TE'&&c.TE>=2)||(p.position==='RB'&&c.RB>=6)||(p.position==='WR'&&c.WR>=7);
 const fallen=Math.max(0,pick-p.adp),bpa=fallen*(2+prof.bpaAggression*3),run=runPressure(p.position,state.picks.map(x=>x.playerId),state.players)*prof.runReaction*5,tier=pool.filter(x=>x.position===p.position&&x.tier===p.tier).length<=2?6:0;
 return Math.max(.01,(48-p.rank*.22)+w*45+(need?8:0)+(blocked?-20:0)+bpa+run+tier);
}

function weightedPick(pool:Player[],team:number,pick:number,rosters:Player[][],state:DraftState,rng:()=>number){
 const candidates=pool.slice().sort((a,b)=>a.rank-b.rank).slice(0,36),scores=candidates.map(p=>Math.exp(opponentProbability(p,team,pick,pool,rosters[team-1],state)/12)),total=scores.reduce((a,b)=>a+b,0),roll=rng()*total;let acc=0;for(let i=0;i<candidates.length;i++){acc+=scores[i];if(acc>=roll)return candidates[i]}return candidates[0];
}

interface SimResult{partner?:Player;gone:Set<string>;before:Record<Position,number>;tierGone:boolean;}
function simulateToNext(state:DraftState,forced:Player,next:number,seed:number):SimResult{
 const rng=seedRand(seed),taken=new Set(state.picks.map(p=>p.playerId));taken.add(forced.id);let pool=state.players.filter(p=>!taken.has(p.id));const rosters=Array.from({length:state.settings.teams},(_,i)=>rosterFor(state.picks,i+1,state.players));rosters[state.settings.mySlot-1]=[...rosters[state.settings.mySlot-1],forced];const gone=new Set<string>(),before=Object.fromEntries(POS.map(p=>[p,0])) as Record<Position,number>;
 for(let pick=state.picks.length+2;pick<next;pick++){const team=pickTeam(pick,state.settings.teams),chosen=weightedPick(pool,team,pick,rosters,state,rng);if(!chosen)break;gone.add(chosen.id);before[chosen.position]++;rosters[team-1].push(chosen);pool=pool.filter(p=>p.id!==chosen.id)}
 const myRoster=rosters[state.settings.mySlot-1],partner=pool.filter(p=>!['K','DST'].includes(p.position)).sort((a,b)=>currentScore(b,pool,myRoster,state,next)-currentScore(a,pool,myRoster,state,next))[0];
 return{partner,gone,before,tierGone:!pool.some(p=>p.position===forced.position&&p.tier===forced.tier)};
}

function threatsFor(player:Player,state:DraftState,next:number):Threat[]{const out:Threat[]=[];for(let pick=state.picks.length+2;pick<next;pick++){const team=pickTeam(pick,state.settings.teams),roster=rosterFor(state.picks,team,state.players),manager=state.managerAssignments[team-1]||'League average',prof=profileFor(state.managerAssignments[team-1]),c=counts(roster),need=player.position==='RB'?c.RB<3:player.position==='WR'?c.WR<3:player.position==='QB'?c.QB<1:player.position==='TE'?c.TE<1:false,prob=clamp((prof.earlyWeights[player.position]*1.7)+(need?.18:0)+(Math.max(0,pick-player.adp)*.025),.03,.88);out.push({team,manager,probability:prob,reason:`${need?'still needs':'has room for'} ${player.position}; ${(prof.earlyWeights[player.position]*100).toFixed(0)}% historical early-position share`})}return out.sort((a,b)=>b.probability-a.probability).slice(0,3)};

export function recommendations(state:DraftState):Recommendation[]{
 const current=state.picks.length+1,pool=state.players.filter(p=>!state.picks.some(x=>x.playerId===p.id)).sort((a,b)=>a.rank-b.rank),roster=rosterFor(state.picks,state.settings.mySlot,state.players),next=nextTurns(current-1,state.settings.mySlot,state.settings.teams,2).find(x=>x>current)??current+state.settings.teams;
 const candidates=pool.filter(p=>currentScore(p,pool,roster,state,current)>-20).slice(0,10),runs=24;
 const result=candidates.map((player,ci)=>{const partnerCounts=new Map<string,number>(),goneCounts=new Map<string,number>(),before=Object.fromEntries(POS.map(p=>[p,0])) as Record<Position,number>;let tierGone=0;for(let s=0;s<runs;s++){const sim=simulateToNext(state,player,next,7919+state.picks.length*101+ci*997+s*37);if(sim.partner)partnerCounts.set(sim.partner.id,(partnerCounts.get(sim.partner.id)??0)+1);sim.gone.forEach(id=>goneCounts.set(id,(goneCounts.get(id)??0)+1));POS.forEach(p=>before[p]+=sim.before[p]);if(sim.tierGone)tierGone++}
 const partnerId=[...partnerCounts].sort((a,b)=>b[1]-a[1])[0]?.[0],partner=pool.find(p=>p.id===partnerId),publicSurvival=baseSurvival(player,next,current),threats=threatsFor(player,state,next),roomDrag=threats.reduce((m,t)=>m*(1-t.probability*.28),1),leagueSurvival=clamp(publicSurvival*roomDrag,.01,.98),partnerRate=partnerId?(partnerCounts.get(partnerId)??0)/runs:0,now=currentScore(player,pool,roster,state,current),future=partner?currentScore(partner,pool,[...roster,player],state,next)*.34*partnerRate:0,wait=1-leagueSurvival,volatility=clamp(.5-Math.abs(.5-leagueSurvival)),strategyAdj=state.strategy==='safe'?-volatility*8:state.strategy==='upside'?volatility*8:0,score=now+future+wait*12+strategyAdj;
 const likelyGone=[...goneCounts].sort((a,b)=>b[1]-a[1]).map(([id])=>pool.find(p=>p.id===id)).filter(Boolean).slice(0,3) as Player[],expected=Object.fromEntries(POS.map(p=>[p,before[p]/runs])) as Record<Position,number>,confidence=clamp(.9-volatility*.65,.48,.92),floor=score-volatility*12,ceiling=score+volatility*16,tierLeft=pool.filter(p=>p.position===player.position&&p.tier===player.tier).length;
 const reasons=[`${Math.round(wait*100)}% league-adjusted wait risk (${Math.round((1-publicSurvival)*100)}% by public ADP)`,tierLeft<=2?`Tier cliff: only ${tierLeft} left in Tier ${player.tier}`:`Simulations preserve ${partner?.name??'a viable partner'} most often`,threats[0]?`${threats[0].manager} is the main snipe threat`:'No strong manager-specific threat'];return{player,partner,score,survival:leagueSurvival,publicSurvival,confidence,volatility,reasons,likelyGone,path:`${player.position} now → ${partner?.position??'BPA'} next`,threats,tierExhaustion:tierGone/runs,expectedBeforeNext:expected,floor,ceiling}}).sort((a,b)=>b.score-a.score);
 const unique:Recommendation[]=[];for(const r of result){if(!unique.some(x=>x.player.id===r.player.id||x.path===r.path))unique.push(r);if(unique.length===3)break}return unique;
}
