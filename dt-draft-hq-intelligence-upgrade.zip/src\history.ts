import raw from './historical-drafts.json';
import type { Position } from './types';

type HistoricalPick={year:number;overall:number;position:Position;manager:string;label:string};
export interface ManagerProfile{
 name:string; sample:number; positionWeights:Record<Position,number>; earlyWeights:Record<Position,number>;
 lateWeights:Record<Position,number>; reachRate:number; bpaAggression:number; runReaction:number;
 rigidity:number; bendPairs:Record<string,number>; firstRound:Record<Position,number>;
}
const picks=raw as HistoricalPick[];
export const managers=[...new Set(picks.map(p=>p.manager))].sort();
const positions:Position[]=['QB','RB','WR','TE','K','DST'];
const empty=()=>Object.fromEntries(positions.map(p=>[p,0])) as Record<Position,number>;
const league=empty();picks.forEach(p=>league[p.position]++);const total=picks.length;

export const profiles:Record<string,ManagerProfile>=Object.fromEntries(managers.map(name=>{
 const mine=picks.filter(p=>p.manager===name),all=empty(),early=empty(),late=empty(),first=empty();
 const byYear=new Map<number,HistoricalPick[]>(); mine.forEach(p=>{all[p.position]++;(p.overall<=70?early:late)[p.position]++;const a=byYear.get(p.year)??[];a.push(p);byYear.set(p.year,a)});
 for(const season of byYear.values()){season.sort((a,b)=>a.overall-b.overall);for(const pos of positions){const found=season.find(p=>p.position===pos);if(found)first[pos]+=Math.ceil(found.overall/14)}}
 const pairs:Record<string,number>={}; for(const season of byYear.values()){season.sort((a,b)=>a.overall-b.overall);for(let i=1;i<season.length;i++)if(season[i].overall-season[i-1].overall<=2){const key=`${season[i-1].position}-${season[i].position}`;pairs[key]=(pairs[key]??0)+1}}
 let runHits=0,runChances=0;for(const p of mine){const before=picks.filter(x=>x.year===p.year&&x.overall<p.overall&&x.overall>=p.overall-4);if(before.length>=3){runChances++;if(before.filter(x=>x.position===p.position).length>=2)runHits++}}
 const smooth=(counts:Record<Position,number>,n:number)=>Object.fromEntries(positions.map(pos=>[pos,(counts[pos]+8*(league[pos]/total))/(n+8)])) as Record<Position,number>;
 const weights=smooth(all,mine.length), earlyW=smooth(early,mine.filter(p=>p.overall<=70).length),lateW=smooth(late,mine.filter(p=>p.overall>70).length);
 const concentration=Math.max(...positions.map(p=>weights[p]));
 return [name,{name,sample:mine.length,positionWeights:weights,earlyWeights:earlyW,lateWeights:lateW,reachRate:.5,bpaAggression:.5+(1-concentration)*.35,runReaction:runChances?runHits/runChances:.25,rigidity:Math.min(.9,concentration*1.7),bendPairs:pairs,firstRound:first}];
}));

export const leagueProfile:ManagerProfile={name:'League average',sample:picks.length,positionWeights:Object.fromEntries(positions.map(p=>[p,league[p]/total])) as Record<Position,number>,earlyWeights:Object.fromEntries(positions.map(p=>[p,league[p]/total])) as Record<Position,number>,lateWeights:Object.fromEntries(positions.map(p=>[p,league[p]/total])) as Record<Position,number>,reachRate:.5,bpaAggression:.55,runReaction:.28,rigidity:.45,bendPairs:{},firstRound:empty()};
export const profileFor=(name?:string)=>name&&profiles[name]?profiles[name]:leagueProfile;
