import type { DraftState } from './types';
const KEY='dt-draft-hq-v1';
export const load=()=>{try{const s=JSON.parse(localStorage.getItem(KEY)||'null') as DraftState|null;if(!s)return null;return{...s,managerAssignments:s.managerAssignments??Array(s.settings.teams).fill(''),watchlist:s.watchlist??[],strategy:s.strategy??'balanced'}}catch{return null}};
export const save=(s:DraftState)=>localStorage.setItem(KEY,JSON.stringify(s));
